Подробно можно узнать о модуле на сайте: https://divleaf.ru/ru/circleblockdrop

Разработчик плагина Divleaf.ru (Nikolay g)
